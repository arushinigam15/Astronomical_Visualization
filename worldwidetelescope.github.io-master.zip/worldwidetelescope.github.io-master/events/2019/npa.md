---
title: WWT @ NPA2019
nav_exclude: true
---

# Archived Event: WWT @ Nordic Planetarium Association Conference 2019

## Sandnes, Norway; 2019 September 7

David Weigel, planetarium director of the US Space and Rocket Center
(Huntsville, AL), gave several WWT-related presentations and workshops at the
[Nordic Planetarium Association Conference 2019](https://www.jaermuseet.no/npaconference/).

Friday talk: “WorldWide Telescope in Planetariums”.

Friday evening workshop:

- How to use WWT in domes
- Installation: as main software, complementary to other systems, etc.
- WWT and Virtual Reality
- WWT and outreach
- Producing tours/shows in WWT

Monday (September 9): a teacher workshop emphasizing WWT in the classroom.
