---
title: WWT @ Mediaglobe Users Group 2015
nav_exclude: true
---

# Archived Event: WWT @ Mediaglobe Users Group 2015

## Jackson, MS, USA; 2015 August 1

- 10:00-11:10: Introduction to WorldWide Telescope and demonstrating how to
  use it
- 11:10-11:20: How WWT can be used in Planetarium and informal education
- 11:20-11:50: Example of how to get Rover Traverse Trail into WWT (David)
- 11:50-Noon: Roundtable of what people want to make in the afternoon session
- Noon-1:00: Lunch
- 1:00-2:40: Hands-on work (potentially in teams)
- 2:40-3:00: Show off what was created

How WWT can be used in planetarium and informal education

- Real time shows
- Production tool for fulldome video
- Connections to classroom or home activities using WWT
- Connection to professional astronomy research (Video Abstracts)
- Sharing of content between planetaria
- Shared dome experiences (future)
