---
title: Edition Notes
nav_order: 5
---

# AAS WorldWide Telescope: Edition Notes

Release notes and supporting materials for the WWT “editions” are collected here.

- [WWT 2022](./2022/)
