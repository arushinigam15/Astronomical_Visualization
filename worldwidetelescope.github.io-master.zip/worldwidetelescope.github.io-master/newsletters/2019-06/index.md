---
title: 2019-06
nav_exclude: true
---

# WWT Newsletter: June 2019

Dear all,

Last week, I promised a big announcement. Here it is:

The AAS WorldWide Telescope team is delighted to announce the launch of the
next-generation WWT community forum website:

<https://wwt-forum.org/>

Many of you have missed the old WWT discussion forum, and we've been wanting to
set up a new one for a while. It's now ready, and the hope is that this will be
a great place for WWT users and contributors to ask questions, share tips, and
learn all about the AAS WorldWide Telescope! Core WWT contributors are signed
on, so this is your chance to interact with the gurus as well as your fellow WWT
fans!

The forum is powered by [Discourse](https://www.discourse.org/), a
highly-regarded open-source platform that's put a great deal of thought and
design effort into how to keep discussions helpful and constructive.

Happy chatting,

Peter
