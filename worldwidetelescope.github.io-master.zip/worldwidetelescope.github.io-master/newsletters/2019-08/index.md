---
title: 2019-08
nav_exclude: true
---

# WWT Newsletter: August 2019

## Two upcoming WWT workshops for astronomy researchers: at AAS235 and ADASS29

Dear WWT fans,

The team is happy to announce two upcoming WWT workshops aimed at astronomy
researchers. They're happening at the following conferences:

- ADASS29 (Groningen, Netherlands; October 6)
- AAS235 (Honolulu, USA; January 5)

If you'd like to get hands-on practice using WWT to explore your data, please
sign up! At both conferences, workshop signup is part of the overall conference
registration process. To learn more, please visit:

<https://bit.ly/wwt-events>

Best,

Peter